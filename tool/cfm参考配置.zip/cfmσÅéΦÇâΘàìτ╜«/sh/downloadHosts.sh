mkdir -p /data/adb/modules/Clash_For_Magisk/system/etc/
curl https://gitlab.com/ineo6/hosts/-/raw/master/next-hosts -o /data/adb/modules/Clash_For_Magisk/system/etc/hosts